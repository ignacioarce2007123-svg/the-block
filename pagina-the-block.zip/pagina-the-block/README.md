# pagina the block

A Pen created on CodePen.

Original URL: [https://codepen.io/Ignacio-Arce-the-vuer/pen/zxvPqZw](https://codepen.io/Ignacio-Arce-the-vuer/pen/zxvPqZw).

